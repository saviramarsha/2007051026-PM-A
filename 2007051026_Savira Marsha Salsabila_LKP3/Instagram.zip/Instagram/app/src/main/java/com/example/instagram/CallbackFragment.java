package com.example.instagram;

public interface CallbackFragment {
    void ChangeFragment();
}
