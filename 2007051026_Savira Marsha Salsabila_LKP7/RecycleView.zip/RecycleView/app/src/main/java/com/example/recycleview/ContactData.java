package com.example.recycleview;

import java.util.ArrayList;

public class ContactData {
    public static String[][] data = new String[][]{
            {"Bakso", "https://i0.wp.com/resepkoki.id/wp-content/uploads/2016/04/Resep-Bakso-urat.jpg?fit=1518%2C1920&ssl=1"},
            {"Nasi Goreng", "http://kbu-cdn.com/dk/wp-content/uploads/nasi-goreng-setan.jpg"},
            {"Mie Goreng", "https://cdn0-production-images-kly.akamaized.net/1k0hYcnhKX2XLbPVhHBtcmeM_6M=/0x104:999x667/1200x675/filters:quality(75):strip_icc():format(webp)/kly-media-production/medias/3467864/original/039604000_1622259396-shutterstock_1873614409.jpg"},
            {"Soto", "https://blue.kumparan.com/image/upload/fl_progressive,fl_lossy,c_fill,q_auto:best,w_640/v1608983819/iwtinvrdf1iwfzc7y6sr.jpg"},
            {"Ayam Goreng", "https://www.resepistimewa.com/wp-content/uploads/ayam-goreng-kalasan-khas-yogya.jpg"},
            {"Ikan Goreng", "https://www.maggi.id/sites/default/files/styles/maggi_desktop_image_style/public/Article%203%20Maret_1500x700pxl_3.jpg?h=4f5b30f1&itok=gDbK8r6_"},
            {"Mie Ayam", "https://www.resepistimewa.com/wp-content/uploads/mie-ayam.jpg"},
            {"Nasi Uduk", "https://asset-a.grid.id/crop/0x0:0x0/945x630/photo/2020/10/13/581050687.jpg"},
            {"Nasi Kuning", "https://sweetrip.id/wp-content/uploads/2021/12/resep-nasi-uduk-kuning.jpg"},
            {"Pecel", "https://cdn1-production-images-kly.akamaized.net/gyvtjxbI5kLqmRm9CvCSnpWWDr4=/0x315:5367x3340/469x260/filters:quality(75):strip_icc():format(webp)/kly-media-production/medias/3012398/original/047469100_1578108085-shutterstock_796820512.jpg"}
    };

    public static ArrayList<Contact> getListData() {
        Contact contact = null;
        ArrayList<Contact> list = new ArrayList<>();
        for (int i = 0; i < data.length; i++) {
            contact = new Contact();
            contact.setName(data[i][0]);
            contact.setPhoto(data[i][1]);
            list.add(contact);
        }
        return list;
    }
}
